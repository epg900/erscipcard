How to use `epfs2` file share
----------------------------
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/epg900/epfs2/blob/main/Youtube.ipynb)
1. clone repository and run `server.py`.
2. enjoy it.
