from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse,FileResponse,JsonResponse,Http404
from django.db.models import Avg, Count, Min, Sum
from django.conf import settings
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.views.decorators.csrf import csrf_exempt
from django.core import serializers
import os,random,json,requests
from .forms import User1form
from .models import User1,SellItem,OrderList,Variz
from docxtpl import DocxTemplate
from docxtpl import InlineImage
#from docx2pdf import convert
from docx.shared import Mm
from pathlib import Path
from django.utils import translation
from django.utils.translation import gettext_lazy as _
from django.utils.html import escape
#from django.core.exceptions import ValidationError
#from django.core.mail import send_mail
#from django.utils.html import format_html
#from .forms import SignupForm,Rsettingform,Tpass
#from .models import Rsetting,Ruser,Pass,PassType,StateType
#from django.contrib import messages
#from django.contrib.auth import update_session_auth_hash
#from django.contrib.auth.forms import PasswordChangeForm
#import pandas as pd
#import os,shutil,threading,random,string,requests
#import os,shutil,pyotp,threading,cryptocompare,random,string,pyqrcode
#from pytube import YouTube
#from datetime import datetime
#from django.contrib.auth.models import User,Permission
####################################################################
def index(request):
	try:		
		if not request.session.session_key:
		    request.session.create()
		request.session['ordernum'] = 0
		ordernumber = request.session['ordernum']
		sid = request.session.session_key
		ordernumber = OrderList.objects.filter(session = sid).count()
		sellitem = SellItem.objects.all().order_by('title')
		content = {'sellitem' : sellitem , 'ordernumber': ordernumber }
		return render (request,'shop/index.html',content)
	except:
		raise Http404("Not Found")
####################################################################
def langen(request):
	#try:
                #data = {'language' : 'en'}
                #requests.post("http://127.0.0.1/i18n/setlang/",data=data)
                translation.activate('en')
                return render (request,'shop/index.html')
	#except:
	#	raise Http404("Not Found")
###################################################################
def addtocart(request):
	try:
		ordernumber=0
		idx=0
		sid = request.session.session_key
		if request.method == 'GET':
			idx=request.GET['idx']
		oli=OrderList.objects.filter(session = sid).filter(sellitem = SellItem.objects.get(id = idx))
		if not oli:
			ol = OrderList()
			ol.session = sid
			ol.sellitem = SellItem.objects.get(id = idx)
			ol.save()
		ordernumber = OrderList.objects.filter(session = sid).count()
		sellitem = SellItem.objects.all().order_by('title')
		content = {'sellitem' : sellitem  , 'ordernumber' : ordernumber}
		return render (request,'shop/index.html',content)
	except:
		raise Http404("Not Found111")
####################################################################
def delorder(request):
	try:
		ordernumber=0
		idx=0
		sid = request.session.session_key
		ordernumber = OrderList.objects.filter(session = sid).count()
		if request.method == 'GET':
			idx=request.GET['idx']
		ol = OrderList.objects.get(id = idx)
		ol.delete()
		sellitem = SellItem.objects.all().order_by('title')
		orderlist = OrderList.objects.filter(session = sid)
		ordersum = OrderList.objects.filter(session = sid).aggregate(Sum('sellitem__price'))
		content = {'sellitem' : sellitem  , 'ordernumber' : ordernumber , 'orderlist' : orderlist , 'ordersum' : ordersum }
		return render (request,'shop/cart.html',content)
	except:
		raise Http404("Not Found115")
####################################################################
def cart(request):
	try:
		ordernumber=0
		idx=0
		sid = request.session.session_key
		ordernumber = OrderList.objects.filter(session = sid).count()
		if ordernumber == 0 :
			return redirect('/')	
		sellitem = SellItem.objects.all().order_by('title')
		orderlist = OrderList.objects.filter(session = sid)
		ordersum = OrderList.objects.filter(session = sid).aggregate(Sum('sellitem__price'))
		content = {'sellitem' : sellitem  , 'ordernumber' : ordernumber , 'orderlist' : orderlist , 'ordersum' : ordersum }
		return render (request,'shop/cart.html',content)
	except:
		raise Http404("Not Found124")
####################################################################
def search(request):
	try:
		ordernumber=0
		p=0
		sid = request.session.session_key
		ordernumber = OrderList.objects.filter(session = sid).count()
		if request.method == 'GET':
			p=request.GET['p']
		sellitem = SellItem.objects.filter(memo__contains = p).order_by('title')
		content = {'sellitem' : sellitem  , 'ordernumber' : ordernumber }
		return render (request,'shop/search.html',content)
	except:
		return HttpResponse(request,_("Error"))
####################################################################
def account(request):
	try:
		return render (request,'shop/account.html')
	except:
		raise Http404("Not Found123")
####################################################################
def setlang(request):
	try:
		if request.GET['cl'] == 'en':
			translation.activate('fa')
		if request.GET['cl'] == 'fa':
			translation.activate('en')
	except:
		pass
	return redirect ('/')
####################################################################
def callinfo(request):
	try:
		return render (request,'shop/callinfo.html')
	except:
		raise Http404("Not Found123")
####################################################################
@csrf_exempt
def variz(request):
	amount=0
	order_id=0
	sid = request.session.session_key
	orderlist = OrderList.objects.filter(session = sid)
	ordersum = OrderList.objects.filter(session = sid).aggregate(Sum('sellitem__price'))
	order_id = sid #random.randint(100,999))	
	amount = ordersum['sellitem__price__sum']
	if amount == 0:
		links = "<p>"
		links +=_("Download Links:")
		for ol in orderlist:
			links += "<br><a href='{}' > {} </a>".format(ol.sellitem.link,ol.sellitem.title) 
		links += "</p>" 
		return render(request, 'shop/index.html',{'error':links})
	data = {"order_id": order_id,"amount": int(amount) * 10 ,"callback": "https://epg.eu.pythonanywhere.com/varizback/"}
	header = {'Content-Type': 'application/json' ,'X-API-KEY': '1111111111111' , 'X-SANDBOX': '0'}
	r = requests.post('https://api.idpay.ir/v1.1/payment' , data=json.dumps(data), headers=header)
	if r.status_code == 201:
		var1=Variz()
		dic1 = r.json()
		var1.idx = dic1['id']
		var1.save()
		return redirect(dic1['link'])
	else:
		dic1 = r.json()
		return render(request, 'shop/index.html', {'error':dic1['error_message']} )
###################################################################
@csrf_exempt
def varizback(request):
	if request.POST['status']=='100':
		var1=Variz.objects.get(idx=request.POST['id'])
		var1.track_id=request.POST['track_id']
		var1.save()
		sid = request.session.session_key
		data = {'id': request.POST['id'] ,'order_id':sid }
		header = {'Content-Type': 'application/json' ,'X-API-KEY': '11111111111111111111' , 'X-SANDBOX': '0'}
		r = requests.post('https://api.idpay.ir/v1.1/payment/verify' , data=json.dumps(data), headers=header )
		sid = request.session.session_key		
		orderlist = OrderList.objects.filter(session = sid)
		links = ""
		for ol in orderlist:
			links += "<a href='{}' > {} </a> ".format(ol.sellitem.link,ol.sellitem.title) 
		return render(request, 'shop/index.html',{'error':escape(links)})
	else:
		return render(request, 'shop/index.html',{'error':'notOK'})
###################################################################
def billinginformation(request):
	try:
		ordernumber=0
		idx=0
		sid = request.session.session_key
		ordernumber = OrderList.objects.filter(session = sid).count()
		sellitem = SellItem.objects.all().order_by('title')
		orderlist = OrderList.objects.filter(session = sid)
		ordersum = OrderList.objects.filter(session = sid).aggregate(Sum('sellitem__price'))
		content = {'sellitem' : sellitem  , 'ordernumber' : ordernumber , 'orderlist' : orderlist , 'ordersum' : ordersum }
		return render (request,'shop/billing-information.html',content)
	except:
		raise Http404("Not Found123")
####################################################################
def logout_form(request):
	try:
		logout(request)
	except:
		pass
	return redirect ('/')
####################################################################
def signin(request):
    try:
        if request.method == 'POST':
            #otp_chk=pyotp.TOTP('H4ZT2CIHQM5XO2VUSZPHWTBHMNQBDY3B')
            username=request.POST['username']
            password=request.POST['password']
            #if username=='admin':
            #    if otpcode!=otp_chk.now():
            #        return redirect ('/')
            user = authenticate(request, username=username, password=password)
            if user is not None :
                login(request , user)
                return redirect ('/')
            else:
                return render(request, 'login.html')
    except:
        return render(request, 'login.html')
    return render(request, 'login.html')
####################################################################
def signup(request):
	if not request.user.is_authenticated:
		return render (request,'login.html' )
	try:
		if request.method == 'POST':
			form = User1form(request.POST , request.FILES )
			if form.is_valid():
				#instance=form.save(commit=False)
				#instance.pic.name="images/{}.png".format(instance.id)
				#instance.save()
				form.save()
				return render(request, 'ou.html', {'memo':'کاربر ساخته شد', 'var1' : 1 })
			else:
			    return render(request, 'ou.html', {'memo':'خطا در ساخت کاربر', 'var1': 1 })
		else:
				form = User1form()
				return render(request, 'ou.html', {'form': form ,  'dest' : 'signup' ,'idx' : 1 , 'var1' : 2  })
	except:
		pass
	return redirect("/")
####################################################################
def changepass(request):
	if not request.user.is_authenticated:
		return render (request,'login.html' )
	#try:
	if request.method == 'POST':
		form = PasswordChangeForm(request.user, request.POST)
		if form.is_valid():
			#instance=form.save(commit=False)
			#instance.pic.name="images/{}.png".format(instance.id)
			#instance.save()
			form.save()
			update_session_auth_hash(request, form.user)
			return render(request, 'ou.html', {'memo':'گذرواژه شما با موفقیت تغییر یافت', 'var1' : 1 })
		else:
		    return render(request, 'ou.html', {'memo':'خطا در تغییر گذرواژه', 'var1': 1 })
	else:
			form = PasswordChangeForm(request.user)
			return render(request, 'ou.html', {'form': form ,  'dest' : 'changepass' ,'idx' : 1 , 'var1' : 2  })
	#except:
	#	pass
	return redirect("/")
####################################################################
def printcard(request):
	if not request.user.is_authenticated:
		return render (request,'login.html' )
	try:
		doc = DocxTemplate(os.path.join(settings.BASE_DIR,"1.docx"))
		user = User1.objects.all()
		pic = {}
		for u in user:
			if u.pic.name != '' :
				pic[u.id] = InlineImage(doc, image_descriptor = u.pic.path , width=Mm(30), height=Mm(40))
		context = {"user" : user  , "pic" : pic }
		doc.render(context)
		doc.save(os.path.join(settings.BASE_DIR, "aa.docx"))
		del doc
		#os.system("docx2pdf {}".format('aa.docx'))
		os.system("lowriter --convert-to pdf  {}".format(os.path.join(settings.BASE_DIR, "aa.docx")))
		f = open(os.path.join(Path(__file__).resolve().parent.parent.parent,"aa.pdf"), 'rb')
		#f = open(os.path.join(settings.BASE_DIR,"aa.pdf"), 'rb')
		pdf_contents = f.read()
		f.close()
		response = HttpResponse(pdf_contents, content_type='application/pdf')
		return response
	except:
		pass
	return redirect("/")
####################################################################
def printcard2(request):
	if not request.user.is_authenticated:
		return render (request,'login.html' )
	try:
		doc = DocxTemplate(os.path.join(settings.BASE_DIR,"1.docx"))
		user = User1.objects.all()
		if request.GET['fromprn'] == '' and request.GET['toprn'] == '' :
			user = User1.objects.all()
		if request.GET['fromprn'] != '' or request.GET['toprn'] != '' :
			user = User1.objects.filter(number=request.GET['fromprn'])
		if request.GET['fromprn'] != '' and request.GET['toprn'] != '' :
			user = User1.objects.filter(number__gte=request.GET['fromprn'],number__lte=request.GET['toprn'])
		#fromprn = request.GET['fromprn']
		#toprn = request.GET['toprn']
		pic = {}
		for u in user:
			if u.pic.name != '' :
				pic[u.id] = InlineImage(doc, image_descriptor = u.pic.path , width=Mm(30), height=Mm(40))
		context = {"user" : user  , "pic" : pic }
		doc.render(context)
		doc.save(os.path.join(settings.BASE_DIR, "aa.docx"))
		del doc
		os.system("lowriter --convert-to pdf  {}".format(os.path.join(settings.BASE_DIR, "aa.docx")))
		#f = open(os.path.join(Path(__file__).resolve().parent.parent.parent,"aa.pdf"), 'rb')
		chk=request.GET["ftype"]
		if chk == "1" :
			f = open(os.path.join(Path(__file__).resolve().parent.parent,"aa.pdf"), 'rb')
		if chk == "2" :
			f = open(os.path.join(settings.BASE_DIR,"aa.docx"), 'rb')
		pdf_contents = f.read()
		f.close()
		if chk == "1" :
			response = HttpResponse(pdf_contents, content_type='application/pdf')
			return response
		if chk == "2" :
			response = HttpResponse(pdf_contents, content_type='application/docx')
			response['Content-Disposition'] = 'inline;filename=cardprn.docx'
			return response
		return redirect("/")
	except:
		pass
	return redirect("/")
####################################################################
def userlist(request):
	if not request.user.is_authenticated:
		return render (request,'login.html' )
	try:
	    if request.method == 'POST':
	        data = request.POST['idnum']
	        userlist=User1.objects.filter(name__contains = data ).order_by('number')
	        return render(request, 'ou.html', {'data': data , 'userlist' : userlist , 'var1' : 3 })
	    else:
	        data = ""
	        userlist=User1.objects.all().order_by('number')
	        return render(request, 'ou.html', {'data': data , 'userlist' : userlist , 'var1' : 3 })
	except:
		pass
	return redirect("/")
####################################################################
def edituser(request):
	if not request.user.is_authenticated:
		return render (request,'login.html' )
	try:
		if request.method == 'POST':
			idx = request.POST['idnum']
			ins1=User1.objects.get(id = idx)
			form =User1form(request.POST , request.FILES ,  instance = ins1)
			if form.is_valid():
				form.save()
				return render(request, 'ou.html', {'memo': 'ویرایش انجام شد' , 'var1' : 1 })
			else:
			    return render(request, 'ou.html', {'memo': 'خطا در ویرایش کاربر', 'var1': 1 })
		else:
				idx = request.GET['id']
				ins1=User1.objects.get(id = idx)
				form =User1form(instance = ins1)
				return render(request, 'ou.html', {'form': form ,  'dest' : 'edituser' ,'idx' : idx , 'var1' : 2  })
	except:
	    return redirect("/")
	return redirect("/")
####################################################################
def deluser(request):
	if not request.user.is_authenticated:
		return render (request,'login.html' )
	try:
		if request.method == 'GET':
			idx = request.GET['id']
			User1.objects.get(id = idx).delete()
	except:
		pass
	return redirect("/userlist")
####################################################################
def uploadtpl(request):
	if not request.user.is_authenticated:
		return render (request,'login.html' )
	try:
		if request.method == 'POST':
			f=request.FILES['file']
			with open(os.path.join(settings.BASE_DIR, "1.docx"), 'wb') as destination:
				for chunk in f.chunks():
				    destination.write(chunk)
			return render(request, 'ou.html',{'memo' : 'فایل آپلود شد!' , 'var1' : 1 })
		else:
			return render(request, 'ou.html', {'var1' : 7 })
	except:
		pass
	return render(request, 'ou.html', {'memo': 'خطا در سرور' , 'var1' : 1 })
###################################################################
def printalluser(request):
	if not request.user.is_authenticated:
		return render (request,'login.html' )
	try:
		doc = DocxTemplate(os.path.join(settings.BASE_DIR,"2.docx"))
		user = User1.objects.all().order_by('number')
		context = {"user" : user }
		doc.render(context)
		doc.save(os.path.join(settings.BASE_DIR, "aa.docx"))
		del doc
		#os.system("docx2pdf {}".format('aa.docx'))
		os.system("lowriter --convert-to pdf  {}".format(os.path.join(settings.BASE_DIR, "aa.docx")))
		f = open(os.path.join(Path(__file__).resolve().parent.parent.parent,"aa.pdf"), 'rb')
		#f = open(os.path.join(settings.BASE_DIR,"aa.pdf"), 'rb')
		pdf_contents = f.read()
		f.close()
		response = HttpResponse(pdf_contents, content_type='application/pdf')
		return response
	except:
		pass
	return redirect("/")
###################################################################
def ajaxload(request):
	data={'data':'ciao'}
	return JsonResponse(data)
###################################################################
def getuserjson(request):
    obj = User1.objects.all()
    data = serializers.serialize('json', obj)
    data = json.loads(data)
    return JsonResponse(data , safe=False)
