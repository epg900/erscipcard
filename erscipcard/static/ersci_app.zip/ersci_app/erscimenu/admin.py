from django.contrib import admin
from erscimenu.models import MenuModel
# Register your models here.
admin.site.register(MenuModel)

#how to use
#from erscimenu.menu import MenuClass
#def index(request):
#	c=MenuClass()
#	return HttpResponse(c)
