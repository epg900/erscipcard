!wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
!dpkg -i cloudflared-linux-amd64.deb
!pip install udocker
!udocker --allow-root install
!udocker --allow-root pull jlesage/firefox
!udocker --allow-root create --name=firefox jlesage/firefox

from threading import Timer

def runcft():
  !cloudflared tunnel --url 127.0.0.1:5800
t=Timer(5,runcft)
t.start()
!udocker --allow-root run -p 5800:5800 firefox