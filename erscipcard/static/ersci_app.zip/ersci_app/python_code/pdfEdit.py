# -*- coding: utf-8 -*-

import fitz
import arabic_reshaper
from bidi.algorithm import get_display
import sys



try:
    input_file = sys.argv[1]
    output_file = "aa2.pdf"
    barcode_file = sys.argv[2]
    # define the position (upper-right corner)
    image_rectangle = fitz.Rect(10,20,110,120)

    # retrieve the first page of the PDF
    doc = fitz.open(input_file)
    page = doc[0]

    # add the image
    page.insert_image(image_rectangle, filename=barcode_file)

    out = open("cc.txt", "wb")  
    text = page.get_text().encode("utf8")
    if sys.argv[3]=="1":
        text = arabic_reshaper.reshape(text)    # correct its shape
        text = get_display(text) 
    if sys.argv[3]=="2":
        text = get_display(text)         # correct its direction
    out.write(text)
    out.close()

    p = fitz.Point(50, 72)  # start point of 1st line

    text = "درود بر شما "
    reshaped_text = arabic_reshaper.reshape(text)    # correct its shape
    bidi_text = get_display(reshaped_text)           # correct its direction


    tt=doc.get_page_fonts(0)
    '''
    page.insert_text(p,  # bottom-left of 1st char
                         bidi_text,  # the text (honors '\n')
                         fontname = tt[0][4],  # the default font
                         fontsize = 18,  # the default font size
                         rotate = 0,  # also available: 90, 180, 270
                         )
    '''                        
    doc.save(output_file)
except Exception as e:
    print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
