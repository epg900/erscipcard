# @title Youtube Downloader
import json, base64, uuid, os, re, time
from IPython.display import HTML, clear_output
from subprocess import Popen , PIPE
!pip install pyqrcode
clear_output()
import pyqrcode

!wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
clear_output()
!dpkg -i cloudflared-linux-amd64.deb
clear_output()
!pip install erscipcard
from erscipcard import inst
clear_output()
!sudo pip install yt-dlp
clear_output()
!pip install vosk
clear_output()

#!pkill python

inst.delproj()
inst.set_config()
!python proj/manage.py makemigrations erscipcard
!python proj/manage.py migrate

clear_output()
Popen("python proj/manage.py runserver".split())
Popen("cloudflared tunnel --url 127.0.0.1:8000 --logfile cloudflared.log".split(), stdout=PIPE, stdin=PIPE, stderr=PIPE)
time.sleep(5)
ff=open("cloudflared.log", "r")
txt=ff.read()
ff.close()
addr=re.findall("https://(.*?.trycloudflare.com)",txt)
clear_output()
config="https://" + addr[0] + "/yt"


url = pyqrcode.create(config)
url.svg('qrcode.svg', scale=8)
imgfile=base64.b64encode(open("qrcode.svg","rb").read()).decode('ascii')

display(HTML("<center><img width='270px' height='270px'  src='data:image/svg+xml;base64,{}' /></center>".format(imgfile)))
html_text = '''<center><input type="hidden" value="{}" id="clipborad-text">
                <button onclick="copyToClipboard()">Copy Link</button>
                <button onclick="clipLink()">Open with clipboard</button>
                <script>
                function copyToClipboard() {{
                    var copyText = document.getElementById("clipborad-text");
                    copyText.select();
                    navigator.clipboard.writeText(copyText.value);
                    alert("Copied the text: " + copyText.value);
                }}
                function get_clip(){{
	              navigator.clipboard.readText().then(text => {{return text;}})
	              .catch(err => {{console.error('Failed to read clipboard contents: ', err);}});
                }}
                function clipLink() {{
                    var copyText = document.getElementById("clipborad-text");
                    copyText+="/ytlink/?url=";
                    cliptext=get_clip();
                    window.open(copyText+cliptext);
                }}
                </script></center>'''.format(config)
display(HTML(html_text))
#time.sleep(7200)
while True: pass
