'''
import json
f=open("1701172080.json")
dd=json.load(f)
f.close()

ss=json.dumps(dd,indent=4)
print(ss)
#for m in dd:
#    print(m)
'''

from netmiko import ConnectHandler
import tqdm,getpass,os
conf={'device_type':'cisco_ios','host':'10.31.242.1','username':'','password':''}
ip_dict={'router_name':'router_ip'}

conf['username']=input('Enter Your Username: ')
conf['password']=getpass.getpass(prompt='Enter Your Password: ')

for key in tqdm.tqdm(ip_dict):
    conf['host']=ip_dict[key]    
    net_obj=ConnectHandler(**conf)
    output=net_obj.send_command("show run")
    f=open(key + ".txt",'w')
    f.write(output)
    f.close()
    net_obj.disconnect()
    
print("\nCompleted!")
os.system('pause')
